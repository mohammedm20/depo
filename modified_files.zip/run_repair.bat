@echo off
setlocal enabledelayedexpansion
chcp 65001 > nul
cd /d "%~dp0"

echo ====================================================
echo  OB-SIMATIC CATALOG - PART NUMBER REPAIR TOOL
echo ====================================================
echo.

set "NODE_CMD="

:: 1. Check if node is available in PATH
where node >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    set "NODE_CMD=node"
    goto :RUN_NODE
)

:: 2. Check standard Windows installation directories
if exist "%ProgramFiles%\nodejs\node.exe" (
    set "NODE_CMD=%ProgramFiles%\nodejs\node.exe"
    goto :RUN_NODE
)
if exist "%ProgramFiles(x86)%\nodejs\node.exe" (
    set "NODE_CMD=%ProgramFiles(x86)%\nodejs\node.exe"
    goto :RUN_NODE
)
if exist "%ProgramW6432%\nodejs\node.exe" (
    set "NODE_CMD=%ProgramW6432%\nodejs\node.exe"
    goto :RUN_NODE
)
if exist "%LOCALAPPDATA%\Programs\nodejs\node.exe" (
    set "NODE_CMD=%LOCALAPPDATA%\Programs\nodejs\node.exe"
    goto :RUN_NODE
)
if exist "%APPDATA%\npm\node.exe" (
    set "NODE_CMD=%APPDATA%\npm\node.exe"
    goto :RUN_NODE
)

:: 3. If Node.js is not found, fallback to Windows PowerShell natively
echo [INFO] Node.js was not detected in system PATH.
echo [INFO] Running repair engine via native Windows PowerShell...
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\repair_catalog.ps1"
if %ERRORLEVEL% EQU 0 (
    echo.
    echo ====================================================
    echo [SUCCESS] Catalog has been repaired successfully!
    echo ====================================================
) else (
    echo.
    echo ====================================================
    echo [ERROR] An error occurred during the repair process.
    echo ====================================================
)
goto :END

:RUN_NODE
echo Running repair script with Node.js...
echo.
"!NODE_CMD!" "%~dp0scripts\repair_catalog.cjs"
if %ERRORLEVEL% EQU 0 (
    echo.
    echo ====================================================
    echo [SUCCESS] Catalog has been repaired successfully!
    echo ====================================================
) else (
    echo.
    echo ====================================================
    echo [ERROR] An error occurred during the repair process.
    echo ====================================================
)

:END
echo.
pause

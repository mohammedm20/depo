@echo off
chcp 65001 > nul
echo ====================================================
echo  OB-SIMATIC CATALOG & PART NUMBER REPAIR TOOL
echo ====================================================
echo.
echo Running repair script...
node scripts/repair_catalog.cjs
if %ERRORLEVEL% EQU 0 (
    echo.
    echo [SUCCESS] Catalog has been repaired successfully!
) else (
    echo.
    echo [ERROR] An error occurred during the repair process.
)
echo.
pause

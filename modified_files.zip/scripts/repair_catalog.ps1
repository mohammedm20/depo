# ==============================================================================
# OB-SIMATIC CATALOG & PART NUMBER REPAIR SCRIPT (PowerShell Edition)
# ==============================================================================
# This script runs on any Windows machine natively without requiring Node.js.
# It repairs, transliterates Turkish characters, normalizes part numbers to
# industrial uppercase, migrates image folders, and creates an automatic backup.
# ==============================================================================

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = Split-Path -Parent $scriptDir
$dataDir = Join-Path $projectRoot "src\data"
$productsFile = Join-Path $dataDir "products.json"
$imagesBaseDir = Join-Path $projectRoot "public\images\products"

Write-Host "====================================================" -ForegroundColor Cyan
Write-Host "   OB-SIMATIC CATALOG - PART NUMBER REPAIR TOOL" -ForegroundColor Cyan
Write-Host " (PowerShell Standalone Edition - No Node.js Required)" -ForegroundColor Gray
Write-Host "====================================================`n" -ForegroundColor Cyan

if (-not (Test-Path $productsFile)) {
    Write-Host "[ERROR] products.json not found at: $productsFile" -ForegroundColor Red
    exit 1
}

# 1. Transliteration Helpers
function Transliterate-Turkish([string]$text) {
    if ([string]::IsNullOrEmpty($text)) { return "" }
    $res = $text
    $res = $res.Replace([string][char]0x0130, "I") # Capital I with dot
    $res = $res.Replace([string][char]0x0131, "I") # Small dotless i
    $res = $res.Replace([string][char]0x015E, "S") # Capital S with cedilla
    $res = $res.Replace([string][char]0x015F, "S") # Small s with cedilla
    $res = $res.Replace([string][char]0x011E, "G") # Capital G with breve
    $res = $res.Replace([string][char]0x011F, "G") # Small g with breve
    $res = $res.Replace([string][char]0x00C7, "C") # Capital C with cedilla
    $res = $res.Replace([string][char]0x00E7, "C") # Small c with cedilla
    $res = $res.Replace([string][char]0x00D6, "O") # Capital O with diaeresis
    $res = $res.Replace([string][char]0x00F6, "O") # Small o with diaeresis
    $res = $res.Replace([string][char]0x00DC, "U") # Capital U with diaeresis
    $res = $res.Replace([string][char]0x00FC, "U") # Small u with diaeresis
    return $res
}

function Clean-PartNumber([string]$rawId) {
    if ([string]::IsNullOrEmpty($rawId)) { return "" }
    $id = Transliterate-Turkish $rawId.Trim()
    $id = $id -replace '[<>:"\/\\|?*=]', '-'
    $id = $id -replace '\s+', '-'
    $id = $id -replace '-+', '-'
    $id = $id -replace '^-+|-+$', ''
    return $id.ToUpper()
}

function Get-SafeDiskFolder([string]$rawId) {
    if ([string]::IsNullOrEmpty($rawId)) { return "" }
    $clean = Transliterate-Turkish $rawId.Trim()
    $clean = $clean -replace '\s+', '-'
    $clean = $clean -replace '[<>:"\/\\|?*]', '-'
    return $clean.ToLower()
}

# 2. Read products.json
try {
    $rawText = [System.IO.File]::ReadAllText($productsFile, [System.Text.Encoding]::UTF8)
    $productsObj = $rawText | ConvertFrom-Json
} catch {
    Write-Host "[ERROR] Failed to read products.json: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

$propList = $productsObj.PSObject.Properties | ForEach-Object { $_ }
$totalProducts = $propList.Count
Write-Host "[INFO] Loaded $totalProducts products from catalog.`n" -ForegroundColor Green

# 3. Create pre-repair backup
$timestamp = (Get-Date).ToString("yyyy-MM-ddTHH-mm-ss-fffZ")
$backupFile = Join-Path $dataDir "products.backup_$timestamp.json"
try {
    [System.IO.File]::WriteAllText($backupFile, $rawText, [System.Text.Encoding]::UTF8)
    Write-Host "[OK] Pre-repair backup created: $(Split-Path -Leaf $backupFile)`n" -ForegroundColor Green
} catch {
    Write-Host "[ERROR] Could not create backup file: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# 4. Process and normalize products
$repairedProducts = [ordered]@{}
$changes = @()
$imageMigrations = @()

foreach ($prop in $propList) {
    $originalId = $prop.Name
    $productData = $prop.Value

    $cleanedId = Clean-PartNumber $originalId

    if ($cleanedId -ne $originalId) {
        $changes += [PSCustomObject]@{
            From = $originalId
            To   = $cleanedId
        }
    }

    # Update internal product.id
    if ($productData.PSObject.Properties.Match('id').Count -gt 0) {
        $productData.id = $cleanedId
    } else {
        $productData | Add-Member -NotePropertyName "id" -NotePropertyValue $cleanedId
    }

    # Check for image folder rename
    $oldSafe = Get-SafeDiskFolder $originalId
    $newSafe = Get-SafeDiskFolder $cleanedId
    if ($oldSafe -ne $newSafe) {
        $imageMigrations += [PSCustomObject]@{
            OldFolder = $oldSafe
            NewFolder = $newSafe
        }
    }

    # Handle duplicate/conflict resolution
    if ($repairedProducts.Contains($cleanedId)) {
        Write-Host "[WARN] ID conflict detected for [$cleanedId]. Merging data..." -ForegroundColor Yellow
        $existing = $repairedProducts[$cleanedId]

        # Fill missing price or category
        if ([string]::IsNullOrEmpty($existing.categorySlug) -and -not [string]::IsNullOrEmpty($productData.categorySlug)) {
            $existing.categorySlug = $productData.categorySlug
        }
        if ($existing.price -eq $null -and $productData.price -ne $null) {
            $existing.price = $productData.price
        }
    } else {
        $repairedProducts[$cleanedId] = $productData
    }
}

# 5. Migrate image folders on disk
$foldersRenamedCount = 0
if (Test-Path $imagesBaseDir) {
    foreach ($mig in $imageMigrations) {
        $oldPath = Join-Path $imagesBaseDir $mig.OldFolder
        $newPath = Join-Path $imagesBaseDir $mig.NewFolder

        if ((Test-Path $oldPath) -and ($oldPath -ne $newPath)) {
            try {
                if (-not (Test-Path $newPath)) {
                    Rename-Item -Path $oldPath -NewName $mig.NewFolder -Force
                    $foldersRenamedCount++
                    Write-Host "[MIGRATE] Renamed image folder: '$($mig.OldFolder)' -> '$($mig.NewFolder)'" -ForegroundColor Cyan
                } else {
                    Get-ChildItem -Path $oldPath | ForEach-Object {
                        $destFile = Join-Path $newPath $_.Name
                        if (-not (Test-Path $destFile)) {
                            Move-Item -Path $_.FullName -Destination $destFile -Force
                        }
                    }
                    Remove-Item -Path $oldPath -Recurse -Force
                    $foldersRenamedCount++
                    Write-Host "[MIGRATE] Merged image folder: '$($mig.OldFolder)' into '$($mig.NewFolder)'" -ForegroundColor Cyan
                }
            } catch {
                Write-Host "[WARN] Could not migrate folder '$($mig.OldFolder)': $($_.Exception.Message)" -ForegroundColor Yellow
            }
        }
    }
}

# 6. Save repaired products.json
try {
    $jsonOut = $repairedProducts | ConvertTo-Json -Depth 100
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($productsFile, $jsonOut, $utf8NoBom)
    Write-Host "`n[OK] Successfully saved cleaned products.json ($($repairedProducts.Count) items)." -ForegroundColor Green
} catch {
    Write-Host "[ERROR] Failed to write repaired products.json: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# 7. Audit Report
Write-Host "`n====================================================" -ForegroundColor Cyan
Write-Host "             REPAIR AUDIT REPORT" -ForegroundColor Cyan
Write-Host "====================================================" -ForegroundColor Cyan
Write-Host "Total Products Examined : $totalProducts"
Write-Host "Total IDs Repaired       : $($changes.Count)"
Write-Host "Image Folders Migrated  : $foldersRenamedCount"

if ($changes.Count -gt 0) {
    Write-Host "`nSample of Repaired Part Numbers:" -ForegroundColor Yellow
    $sample = $changes | Select-Object -First 20
    $idx = 1
    foreach ($c in $sample) {
        Write-Host "  $idx. [$($c.From)]  -->  [$($c.To)]"
        $idx++
    }
    if ($changes.Count -gt 20) {
        Write-Host "  ... and $($changes.Count - 20) more items."
    }
} else {
    Write-Host "`n[OK] All product part numbers are already clean and valid!" -ForegroundColor Green
}

Write-Host "`n[OK] All part numbers are now 100% compliant with industrial standards." -ForegroundColor Green
Write-Host "====================================================`n" -ForegroundColor Cyan

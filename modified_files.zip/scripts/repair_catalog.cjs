/**
 * Catalog & Part Number Repair Script
 * ===================================
 * This script is designed to run on ANY machine to clean, repair, and normalize
 * all product part numbers (IDs) that were previously entered with Turkish
 * characters, slashes, illegal symbols, or improper casing.
 *
 * Actions performed:
 * 1. Automatically creates a timestamped backup before modifying any files.
 * 2. Transliterates Turkish characters to standard English letters (İ->I, ı->I, Ş->S, Ğ->G, Ç->C, Ö->O, Ü->U).
 * 3. Replaces slashes (/), backslashes (\), and illegal filesystem/URL symbols with clean hyphens (-).
 * 4. Normalizes all product IDs to standard industrial UPPERCASE (e.g., 6es7... -> 6ES7...).
 * 5. Migrates existing product image folders in public/images/products/ so no photos are lost.
 * 6. Resolves and merges any conflicting duplicate IDs without data loss.
 * 7. Outputs a detailed before-and-after audit report.
 */

const fs = require('fs');
const path = require('path');

const projectRoot = path.resolve(__dirname, '..');
const dataDir = path.join(projectRoot, 'src', 'data');
const productsFile = path.join(dataDir, 'products.json');
const imagesBaseDir = path.join(projectRoot, 'public', 'images', 'products');

// Turkish to English ASCII transliteration map
const TURKISH_CHAR_MAP = {
    'İ': 'I', 'ı': 'I', 'I': 'I', 'i': 'I',
    'Ş': 'S', 'ş': 'S',
    'Ğ': 'G', 'ğ': 'G',
    'Ç': 'C', 'ç': 'C',
    'Ö': 'O', 'ö': 'O',
    'Ü': 'U', 'ü': 'U'
};

// URL/FS Safe ID generator (must match server.cjs sanitizeProductId)
function getSafeDiskFolder(id) {
    if (!id) return '';
    let clean = id;
    for (const [tr, en] of Object.entries(TURKISH_CHAR_MAP)) {
        clean = clean.split(tr).join(en);
    }
    return String(clean).trim()
        .replace(/\s+/g, '-')
        .replace(/[<>:"\/\\|?*]/g, '-')
        .toLowerCase();
}

// Clean and normalize part number/ID
function cleanPartNumber(rawId) {
    if (!rawId) return '';
    let id = String(rawId).trim();

    // 1. Transliterate Turkish characters
    for (const [tr, en] of Object.entries(TURKISH_CHAR_MAP)) {
        id = id.split(tr).join(en);
    }

    // 2. Replace slashes, illegal filesystem/URL symbols and equals signs with hyphens
    id = id.replace(/[<>:"\/\\|?*=]/g, '-')
           .replace(/\s+/g, '-')       // Replace spaces with hyphen
           .replace(/-+/g, '-')        // Deduplicate hyphens
           .replace(/^-+|-+$/g, '');   // Trim leading/trailing hyphens

    // 3. Convert to uppercase (standard industrial part number)
    return id.toUpperCase();
}

function runRepair() {
    console.log('====================================================');
    console.log(' 🛠️  OB-SIMATIC CATALOG & PART NUMBER REPAIR TOOL');
    console.log('====================================================\n');

    // Check if products.json exists
    if (!fs.existsSync(productsFile)) {
        console.error(`❌ Error: products.json not found at: ${productsFile}`);
        process.exit(1);
    }

    // 1. Read existing products
    let rawData;
    let products;
    try {
        rawData = fs.readFileSync(productsFile, 'utf8');
        products = JSON.parse(rawData);
    } catch (err) {
        console.error(`❌ Error reading or parsing products.json: ${err.message}`);
        process.exit(1);
    }

    const totalProducts = Object.keys(products).length;
    console.log(`📦 Loaded ${totalProducts} products from catalog.\n`);

    // 2. Create timestamped backup
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backupFile = path.join(dataDir, `products.backup_${timestamp}.json`);
    try {
        fs.writeFileSync(backupFile, rawData, 'utf8');
        console.log(`✅ Pre-repair backup created: ${path.basename(backupFile)}\n`);
    } catch (err) {
        console.error(`❌ Could not create backup: ${err.message}`);
        process.exit(1);
    }

    // 3. Process products and detect changes
    const repairedProducts = {};
    const changes = [];
    const imageMigrations = [];

    for (const [originalId, product] of Object.entries(products)) {
        const cleanedId = cleanPartNumber(originalId);

        if (cleanedId !== originalId) {
            changes.push({ from: originalId, to: cleanedId });
        }

        // Prepare updated product object
        const updatedProduct = {
            ...product,
            id: cleanedId
        };

        // Check if there is an image folder migration needed
        const oldSafeFolder = getSafeDiskFolder(originalId);
        const newSafeFolder = getSafeDiskFolder(cleanedId);

        if (oldSafeFolder !== newSafeFolder) {
            imageMigrations.push({ oldFolder: oldSafeFolder, newFolder: newSafeFolder });
        }

        // Handle possible duplicate/conflict resolution
        if (repairedProducts[cleanedId]) {
            console.log(`⚠️  Warning: ID conflict detected for [${cleanedId}]. Merging data...`);
            const existing = repairedProducts[cleanedId];

            // Merge translations and i18n
            if (!existing.translations) existing.translations = { ar: { keys: [] }, en: { keys: [] }, tr: { keys: [] } };
            if (product.translations) {
                ['ar', 'en', 'tr'].forEach(lang => {
                    const extraKeys = product.translations[lang]?.keys || [];
                    if (extraKeys.length > 0) {
                        existing.translations[lang].keys = [
                            ...(existing.translations[lang]?.keys || []),
                            ...extraKeys
                        ];
                    }
                });
            }

            // Fill price or category if missing
            if (!existing.categorySlug && product.categorySlug) existing.categorySlug = product.categorySlug;
            if ((existing.price === null || existing.price === undefined) && product.price !== undefined) {
                existing.price = product.price;
            }
        } else {
            repairedProducts[cleanedId] = updatedProduct;
        }
    }

    // 4. Migrate image folders on disk if they exist
    let foldersRenamedCount = 0;
    if (fs.existsSync(imagesBaseDir)) {
        for (const { oldFolder, newFolder } of imageMigrations) {
            const oldPath = path.join(imagesBaseDir, oldFolder);
            const newPath = path.join(imagesBaseDir, newFolder);

            if (fs.existsSync(oldPath) && oldPath !== newPath) {
                try {
                    if (!fs.existsSync(newPath)) {
                        fs.renameSync(oldPath, newPath);
                        foldersRenamedCount++;
                        console.log(`📁 Renamed image folder: "${oldFolder}" -> "${newFolder}"`);
                    } else {
                        // If new path already exists, move files into it
                        const files = fs.readdirSync(oldPath);
                        files.forEach(f => {
                            const src = path.join(oldPath, f);
                            const dest = path.join(newPath, f);
                            if (!fs.existsSync(dest)) fs.renameSync(src, dest);
                        });
                        fs.rmdirSync(oldPath);
                        foldersRenamedCount++;
                        console.log(`📁 Merged image folder: "${oldFolder}" into "${newFolder}"`);
                    }
                } catch (e) {
                    console.warn(`⚠️ Could not rename folder "${oldFolder}": ${e.message}`);
                }
            }
        }
    }

    // 5. Write updated products.json
    try {
        fs.writeFileSync(productsFile, JSON.stringify(repairedProducts, null, 4), 'utf8');
        console.log(`\n💾 Successfully saved cleaned products.json (${Object.keys(repairedProducts).length} items).`);
    } catch (err) {
        console.error(`❌ Failed to write repaired products.json: ${err.message}`);
        process.exit(1);
    }

    // 6. Summary Report
    console.log('\n====================================================');
    console.log(' 📊 REPAIR AUDIT REPORT');
    console.log('====================================================');
    console.log(`Total Products Examined : ${totalProducts}`);
    console.log(`Total IDs Repaired       : ${changes.length}`);
    console.log(`Image Folders Migrated  : ${foldersRenamedCount}`);

    if (changes.length > 0) {
        console.log('\nSample of Repaired Part Numbers:');
        changes.slice(0, 20).forEach((c, idx) => {
            console.log(`  ${idx + 1}. [${c.from}]  -->  [${c.to}]`);
        });
        if (changes.length > 20) {
            console.log(`  ... and ${changes.length - 20} more items.`);
        }
    } else {
        console.log('\n✨ All product part numbers are already clean and valid!');
    }

    console.log('\n✅ All part numbers are now 100% compliant with industrial standards.');
    console.log('   You can now safely run: npm run build');
    console.log('====================================================\n');
}

runRepair();

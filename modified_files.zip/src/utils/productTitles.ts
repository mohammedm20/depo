import { getCategoriesSync } from "./dataReader";
const categories = getCategoriesSync();
import { DEFAULT_LANGUAGE, type Language } from "./i18n";

type ProductLike = {
    id: string;
    categorySlug?: string;
    i18n?: Record<string, { title?: string }>;
};

/** The only title allowed to appear in the product-page UI. */
export function getManualProductTitle(product: ProductLike, lang: Language): string {
    const languages = [lang, DEFAULT_LANGUAGE, "en", "tr", "ar"];
    for (const language of [...new Set(languages)]) {
        const title = product.i18n?.[language]?.title?.trim();
        if (title) return title;
    }
    return "";
}

/** UI fallback: never exposes category names as a product title. */
export function getVisibleProductTitle(product: ProductLike, lang: Language): string {
    return getManualProductTitle(product, lang) || product.id;
}

function localizedCategoryName(category: any, lang: Language): string {
    const languages = [lang, DEFAULT_LANGUAGE, "en", "tr", "ar"];
    for (const language of [...new Set(languages)]) {
        const name = category?.i18n?.[language]?.name?.trim();
        if (name) return name;
    }
    return "";
}

/**
 * A concise SEO-only fallback for products that have no admin-entered title.
 * It does not write to products.json and must never be used as the visible H1.
 */
export function getProductSeoTitle(product: ProductLike, lang: Language): string {
    const manualTitle = getManualProductTitle(product, lang);
    if (manualTitle) return manualTitle;

    const chain: any[] = [];
    const seen = new Set<string>();
    let slug = product.categorySlug;
    while (slug && (categories as any)[slug] && !seen.has(slug)) {
        seen.add(slug);
        const category = (categories as any)[slug];
        chain.unshift(category);
        slug = category.parentSlug;
    }

    const names = chain.map(category => localizedCategoryName(category, lang)).filter(Boolean);
    // Usually: root > brand > family > leaf. Keep brand and the two most specific levels.
    const context = names.length > 1
        ? [names[1], ...names.slice(-2)]
        : names;
    const uniqueContext = [...new Map(context.map(name => [name.toLocaleLowerCase(), name])).values()];

    return uniqueContext.length > 0
        ? `${product.id} | ${uniqueContext.join(" | ")}`
        : product.id;
}

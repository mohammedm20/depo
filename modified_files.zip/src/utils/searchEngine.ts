
// Works with both a custom domain (/) and GitHub Pages subpaths (/home).
const BASE_URL = (import.meta.env.BASE_URL || '/').replace(/\/$/, '');

export interface SearchItem {
    type: 'product' | 'category';
    id: string;
    title_tr: string;
    title_en: string;
    title_ar: string;
    image: string;
    categorySlug?: string;
    brand?: string;
    brandSearch?: string;
    inStock?: boolean;
    price?: string | number;
    parentSlug?: string;
}

export interface SearchFilters {
    q: string;
    brand: string[];
    inStock: boolean;
    contactPrice: boolean;
    minPrice: number;
    maxPrice: number;
}

/**
 * Normalizes text for search, handling:
 * 1. Turkish uppercase letters: 'İ' -> 'i', 'I' -> 'i', 'ı' -> 'i'
 * 2. Turkish accented characters: 'ş' -> 's', 'ğ' -> 'g', 'ç' -> 'c', 'ö' -> 'o', 'ü' -> 'u'
 * 3. Arabic variants: 'أ/إ/آ' -> 'ا', 'ة' -> 'ه', 'ى' -> 'ي'
 * 4. General Unicode diacritic marks removal via NFD
 * 5. Case-folding to lowercase and trimming
 */
export function normalizeSearchText(text: string): string {
    if (!text) return '';
    return String(text)
        .replace(/\u0130/g, 'i') // Turkish capital I with dot 'İ' -> 'i'
        .replace(/\u0131/g, 'i') // Turkish lowercase dotless 'ı' -> 'i'
        .replace(/[İIıi]/g, 'i')
        .replace(/[Şş]/g, 's')
        .replace(/[Ğğ]/g, 'g')
        .replace(/[Çç]/g, 'c')
        .replace(/[Öö]/g, 'o')
        .replace(/[Üü]/g, 'u')
        .replace(/[أإآ]/g, 'ا')
        .replace(/ة/g, 'ه')
        .replace(/ى/g, 'ي')
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .toLowerCase()
        .trim();
}

/**
 * Compacts search text by removing all spaces, dashes, slashes, dots and symbols
 * so that part numbers like "6ES7 414-3EM07-0AB0" match "6es7414" or "6ES7 414" seamlessly.
 */
export function compactSearchText(text: string): string {
    return normalizeSearchText(text).replace(/[\s\-_/.,:;()]+/g, '');
}

/**
 * Calculates a relevance score for a product given a user query.
 * Returns > 0 if matched (higher = more relevant), 0 if no match.
 */
export function calculateProductRelevance(item: SearchItem, query: string): number {
    if (!query) return 1;

    const qNorm = normalizeSearchText(query);
    const qCompact = compactSearchText(query);
    if (!qNorm && !qCompact) return 0;

    const idNorm = normalizeSearchText(item.id || '');
    const idCompact = compactSearchText(item.id || '');
    const titleNorm = normalizeSearchText(`${item.title_tr || ''} ${item.title_en || ''} ${item.title_ar || ''}`);
    const titleCompact = compactSearchText(`${item.title_tr || ''} ${item.title_en || ''} ${item.title_ar || ''}`);
    const brandNorm = normalizeSearchText(item.brand || '');
    const brandSearchNorm = normalizeSearchText(item.brandSearch || '');
    const fullNorm = `${idNorm} ${titleNorm} ${brandNorm} ${brandSearchNorm}`;

    const tokens = qNorm.split(/\s+/).filter(Boolean);
    const tokenCompactList = tokens.map(t => compactSearchText(t)).filter(Boolean);

    let score = 0;
    let matched = false;

    // 1. Direct Part Number / ID matches (Highest Priority)
    if (idCompact === qCompact) {
        score += 10000; // Perfect match on part number!
        matched = true;
    } else if (idCompact.startsWith(qCompact)) {
        score += 5000; // Part number starts with query
        matched = true;
    } else if (idCompact.includes(qCompact)) {
        score += 2500; // Part number contains query
        matched = true;
    } else if (idNorm.includes(qNorm)) {
        score += 2000;
        matched = true;
    }

    // 2. Title matches
    if (titleCompact === qCompact) {
        score += 4000;
        matched = true;
    } else if (titleNorm.startsWith(qNorm)) {
        score += 1800;
        matched = true;
    } else if (titleNorm.includes(qNorm)) {
        score += 1000;
        matched = true;
    }

    // 3. Brand matches
    if (brandNorm === qNorm || brandSearchNorm.split(/\s+/).some(b => b === qNorm)) {
        score += 1200;
        matched = true;
    } else if (brandSearchNorm.includes(qNorm)) {
        score += 500;
        matched = true;
    }

    // 4. Multi-token evaluation (e.g. "6ES7 414" or "Siemens PLC")
    if (tokens.length > 0) {
        let allTokensMatched = true;
        for (let i = 0; i < tokens.length; i++) {
            const token = tokens[i];
            const tokenComp = tokenCompactList[i] || token;
            let tokenHit = false;

            if (idCompact.includes(tokenComp)) {
                score += 800;
                tokenHit = true;
            }
            if (titleNorm.includes(token)) {
                score += 300;
                tokenHit = true;
            }
            if (brandSearchNorm.includes(token)) {
                score += 200;
                tokenHit = true;
            }

            if (!tokenHit) {
                allTokensMatched = false;
            }
        }

        if (allTokensMatched && tokens.length > 1) {
            score += 1500;
            matched = true;
        }
    }

    // 5. Fallback full content match
    if (!matched) {
        if (fullNorm.includes(qNorm) || (qCompact && idCompact.includes(qCompact))) {
            score += 200;
            matched = true;
        }
    }

    if (!matched) return 0;

    // Tie-breaker 1: In-stock items receive small bonus
    if (item.inStock !== false) {
        score += 15;
    }

    // Tie-breaker 2: Shorter part numbers that match are more specific
    const lenDiff = Math.abs(idNorm.length - qNorm.length);
    score += Math.max(0, 30 - lenDiff);

    return score;
}

/**
 * Calculates a relevance score for a category given a user query.
 */
export function calculateCategoryRelevance(item: SearchItem, query: string): number {
    if (!query) return 0;
    const qNorm = normalizeSearchText(query);
    if (!qNorm) return 0;

    const idNorm = normalizeSearchText(item.id || '');
    const titleNorm = normalizeSearchText(`${item.title_tr || ''} ${item.title_en || ''} ${item.title_ar || ''}`);

    let score = 0;
    if (titleNorm === qNorm || idNorm === qNorm) {
        score += 5000;
    } else if (titleNorm.startsWith(qNorm) || idNorm.startsWith(qNorm)) {
        score += 2500;
    } else if (titleNorm.includes(qNorm) || idNorm.includes(qNorm)) {
        score += 1000;
    }

    const tokens = qNorm.split(/\s+/).filter(Boolean);
    if (tokens.length > 1) {
        let allMatched = true;
        for (const token of tokens) {
            if (titleNorm.includes(token) || idNorm.includes(token)) {
                score += 200;
            } else {
                allMatched = false;
            }
        }
        if (allMatched) score += 800;
    }

    return score;
}

export class SearchEngine {
    private static instance: SearchEngine;
    private index: SearchItem[] = [];
    private isLoaded = false;
    private currentLang: string = 'tr';

    private constructor() {
        if (typeof document !== 'undefined') {
            this.currentLang = document.documentElement.lang || 'tr';
        }
    }

    public static getInstance(): SearchEngine {
        if (!SearchEngine.instance) {
            SearchEngine.instance = new SearchEngine();
        }
        return SearchEngine.instance;
    }

    public async init() {
        if (this.isLoaded && this.index.length > 0) return;

        if (typeof window !== 'undefined' && (window as any).__SEARCH_INDEX__) {
            this.index = (window as any).__SEARCH_INDEX__;
            this.isLoaded = true;
            return;
        }

        try {
            const res = await fetch(`${BASE_URL}/api/search-index.json`);
            if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
            this.index = await res.json();
            this.isLoaded = true;
            if (typeof window !== 'undefined') {
                (window as any).__SEARCH_INDEX__ = this.index;
            }
        } catch (err) {
            console.error("SearchEngine init error:", err);
        }
    }

    public getIsLoaded() {
        return this.isLoaded;
    }

    public search(filters: SearchFilters) {
        const query = (filters.q || '').trim();
        const hasQuery = Boolean(query);

        // Filter and score products
        const scoredProducts: { item: SearchItem; score: number }[] = [];

        for (const item of this.index) {
            if (item.type !== 'product') continue;

            // Brand filter
            if (filters.brand.length > 0) {
                const normFilters = filters.brand.map(b => normalizeSearchText(b));
                const itemBrandNorm = normalizeSearchText(item.brand || '');
                if (!itemBrandNorm || !normFilters.includes(itemBrandNorm)) {
                    continue;
                }
            }

            // Stock filter
            if (filters.inStock && item.inStock === false) continue;

            // Price filter
            const isContact = item.price === 'contact' || item.price === '0' || item.price === 0 || isNaN(Number(item.price));
            if (filters.contactPrice) {
                if (!isContact) continue;
            } else {
                if (isContact && (filters.minPrice > 0 || filters.maxPrice < Infinity)) continue;
                const price = Number(item.price) || 0;
                if (price < filters.minPrice || (filters.maxPrice < Infinity && price > filters.maxPrice)) continue;
            }

            // Text search & relevance calculation
            let score = 1;
            if (hasQuery) {
                score = calculateProductRelevance(item, query);
                if (score <= 0) continue;
            }

            scoredProducts.push({ item, score });
        }

        // Sort products by score descending (highest relevance first)
        if (hasQuery) {
            scoredProducts.sort((a, b) => b.score - a.score);
        }

        const filteredProducts = scoredProducts.map(sp => sp.item);

        // Filter and score categories
        const scoredCategories: { item: SearchItem; score: number }[] = [];
        if (hasQuery) {
            for (const item of this.index) {
                if (item.type !== 'category') continue;
                const score = calculateCategoryRelevance(item, query);
                if (score > 0) {
                    scoredCategories.push({ item, score });
                }
            }
            scoredCategories.sort((a, b) => b.score - a.score);
        }
        const filteredCategories = scoredCategories.map(sc => sc.item);

        return {
            products: filteredProducts,
            categories: filteredCategories,
            totalProducts: filteredProducts.length,
            totalCategories: filteredCategories.length,
        };
    }

    public getFacetedCounts(filters: Omit<SearchFilters, 'brand'>) {
        const query = (filters.q || '').trim();
        const hasQuery = Boolean(query);
        const counts: Record<string, number> = {};

        this.index.forEach(item => {
            if (item.type !== 'product' || !item.brand) return;

            let wouldBeVisible = true;

            if (hasQuery) {
                const score = calculateProductRelevance(item, query);
                if (score <= 0) wouldBeVisible = false;
            }

            if (filters.inStock && item.inStock === false) wouldBeVisible = false;

            const isContact = item.price === 'contact' || item.price === '0' || item.price === 0 || isNaN(Number(item.price));
            if (filters.contactPrice) {
                if (!isContact) wouldBeVisible = false;
            } else {
                if (isContact && (filters.minPrice > 0 || filters.maxPrice < Infinity)) wouldBeVisible = false;
                const price = Number(item.price) || 0;
                if (price < filters.minPrice || (filters.maxPrice < Infinity && price > filters.maxPrice)) wouldBeVisible = false;
            }

            if (wouldBeVisible) {
                counts[item.brand] = (counts[item.brand] || 0) + 1;
            }
        });

        return counts;
    }
}


import { getCategoriesSync } from "./dataReader";
const categories = getCategoriesSync();
import { type Language } from "./i18n";

/**
 * Normalizes a string to be used as a canonical ID (lowercase, alphanumeric)
 */
function normalizeBrandName(name: string): string {
    return name
        .toLowerCase()
        .trim()
        .replace(/[^a-z0-9]/g, '-')
        .replace(/-+/g, '-')
        .replace(/^-|-$/g, '');
}

/**
 * Derives the brand slug for a product based on its category slug.
 * Brand is defined as the Level 2 category in the hierarchy.
 * Returns a canonical normalized slug (e.g., "siemens" instead of "siemens-industry").
 */
export function getProductBrandSlug(categorySlug: string): string {
    if (!categorySlug || !categories[categorySlug as keyof typeof categories]) return "Other";

    let current = (categories as any)[categorySlug];
    const chain = [current];

    // Build chain up to root
    while (current.parentSlug && (categories as any)[current.parentSlug]) {
        current = (categories as any)[current.parentSlug];
        chain.unshift(current);
    }

    // chain[0] is Root, chain[chain.length - 1] is Leaf.

    // 1. Explicit Dynamic Brand Check (search from leaf to root to find the closest company)
    for (let i = chain.length - 1; i >= 0; i--) {
        if (chain[i].type === 'brand') {
            const brandCategory = chain[i];
            const brandName = brandCategory.i18n?.["en"]?.name || brandCategory.slug;
            return normalizeBrandName(brandName);
        }
    }

    // 2. Legacy Fallback Check (Level 2 is Brand)
    // Root is index 0. Brand is index 1 (Level 2)
    if (chain.length >= 2) {
        const brandCategory = chain[1];
        // Use English name for canonical ID to ensure it's language-invariant
        const brandName = brandCategory.i18n?.["en"]?.name || brandCategory.slug;
        return normalizeBrandName(brandName);
    }
    
    return "Other";
}

/**
 * Gets the localized brand name for a given brand slug (canonical).
 * Since we now use names as IDs, we might need a reverse lookup or just return the name.
 * However, for backward compatibility and simplicity, if it's a known slug, we get its name.
 */
export function getBrandNameFromSlug(slug: string, lang: Language): string {
    if (slug === "Other" || slug === "other") {
        return lang === "ar" ? "آخر" : lang === "en" ? "Other" : "Diğer";
    }
    
    // We try to find a category that matches this normalized slug to get its proper case/localized name
    const allCategories = Object.values(categories);
    const matchingCat = allCategories.find((cat: any) => {
        const enName = cat.i18n?.["en"]?.name || cat.slug;
        return normalizeBrandName(enName) === slug;
    });

    if (matchingCat) {
        const cat = matchingCat as any;
        return cat.i18n[lang]?.name || cat.i18n["en"]?.name || cat.i18n["tr"]?.name || slug;
    }
    
    // Fallback: capitalize first letter if not found
    return slug.charAt(0).toUpperCase() + slug.slice(1);
}

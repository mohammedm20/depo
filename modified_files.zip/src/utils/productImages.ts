/**
 * Product Images Utility
 * Dynamically discovers images from the file system instead of relying on JSON
 */

import fs from 'fs';
import path from 'path';
import { formatUrlSlug } from './urlFormatter';

const IMAGE_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg'];

// Base URL for Astro (dynamic)
const BASE_URL = import.meta.env.BASE_URL.replace(/\/$/, '');
// [FIX] في وضع التطوير لا نستخدم cache حتى تظهر التغييرات فوراً
const IS_DEV = import.meta.env.DEV;

// --- CACHING LOGIC ---
let cachedFolders: string[] | null = null;
let folderMap: Map<string, string> = new Map(); // slug -> actualFolderName
const imageCache: Map<string, string[]> = new Map(); // productId -> imagePaths[]
let lastCacheTime = 0;
const DEV_CACHE_TTL = 3000; // 3 seconds in dev to avoid repeating thousands of fs calls per render

function isCacheValid(): boolean {
    if (!cachedFolders || folderMap.size === 0) return false;
    if (!IS_DEV) return true;
    return (Date.now() - lastCacheTime) < DEV_CACHE_TTL;
}

/**
 * Clear the image discovery cache (call this when images are uploaded/deleted)
 */
export function clearImageCache() {
    cachedFolders = null;
    folderMap.clear();
    imageCache.clear();
    lastCacheTime = 0;
}

function getFolders(productsDir: string): Map<string, string> {
    if (isCacheValid()) return folderMap;

    try {
        if (!fs.existsSync(productsDir)) return new Map();
        
        const entries = fs.readdirSync(productsDir);
        const map = new Map<string, string>();
        
        for (const entry of entries) {
            const folderPath = path.join(productsDir, entry);
            if (fs.lstatSync(folderPath).isDirectory()) {
                map.set(formatUrlSlug(entry), entry);
            }
        }
        
        folderMap = map;
        cachedFolders = entries;
        lastCacheTime = Date.now();
        return folderMap;
    } catch (e) {
        console.error(`[DEBUG] Error scanning products directory:`, e);
        return new Map();
    }
}

export function getProductImages(productId: string): string[] {
    if (!productId) return [];

    // Check memory cache first
    if (isCacheValid() && imageCache.has(productId)) {
        return imageCache.get(productId) || [];
    }

    const rootDir = process.cwd();
    const productsDir = path.join(rootDir, 'public', 'images', 'products');
    const safeTarget = formatUrlSlug(productId);

    try {
        const folders = getFolders(productsDir);
        const actualFolder = folders.get(safeTarget);

        if (!actualFolder) {
            imageCache.set(productId, []);
            return [];
        }

        const productDir = path.join(productsDir, actualFolder);
        const files = fs.readdirSync(productDir);

        const images = files.filter(file => {
            const ext = path.extname(file).toLowerCase();
            return IMAGE_EXTENSIONS.includes(ext);
        }).map(img => `${BASE_URL}/images/products/${actualFolder}/${encodeURIComponent(img)}`);

        // Cache the result
        imageCache.set(productId, images);
        return images;
    } catch (error) {
        console.error(`[DEBUG] Error reading product images for ${productId}:`, error);
        return [];
    }
}

/**
 * Get the default product image dynamically
 */
export function getDefaultImage(): string {
    // Since the 'default' folder was removed, we return an empty string.
    // Frontend components should handle this by showing a placeholder or icon.
    return '';
}

/**
 * Get the primary (first) image for a product
 * Falls back to dynamic default image if none found
 * @param productId - The product ID
 * @param defaultImage - Optional override for default image
 * @returns Image path or default
 */
export function getProductImage(productId: string, defaultImage?: string): string {
    const images = getProductImages(productId);
    if (images.length > 0) return images[0];

    // [FIX] تحقق من وجود الملف فعلاً قبل إرجاع المسار
    if (defaultImage) {
        try {
            const rootDir = process.cwd();
            let relativePath = defaultImage;
            if (BASE_URL && relativePath.startsWith(BASE_URL)) {
                relativePath = relativePath.slice(BASE_URL.length);
            }
            const decodedPath = decodeURIComponent(relativePath);
            const absolutePath = path.join(rootDir, 'public', decodedPath.startsWith('/') ? decodedPath.slice(1) : decodedPath);
            if (fs.existsSync(absolutePath)) {
                // الملف موجود - أضف BASE_URL وأرجعه
                if (defaultImage.startsWith('http') || (BASE_URL && defaultImage.startsWith(BASE_URL))) {
                    return defaultImage;
                }
                return `${BASE_URL}${defaultImage.startsWith('/') ? ''  : '/'}${defaultImage}`;
            }
            // الملف محذوف - أرجع فارغاً ليظهر placeholder
            return '';
        } catch (e) {
            return '';
        }
    }
    return getDefaultImage();
}

/**
 * Check if a product has any images
 * @param productId - The product ID
 * @returns boolean
 */
export function productHasImage(productId: string): boolean {
    return getProductImages(productId).length > 0;
}

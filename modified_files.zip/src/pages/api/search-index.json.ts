
import { getProductImage } from "../../utils/productImages";
import fs from "node:fs";
import path from "node:path";
import { getProductBrandSlug, getBrandNameFromSlug } from "../../utils/brandUtils";

export async function GET() {
    const productsPath = path.join(process.cwd(), "src", "data", "products.json");
    const categoriesPath = path.join(process.cwd(), "src", "data", "categories.json");

    let products = {};
    let categories = {};

    try {
        if (fs.existsSync(productsPath)) {
            products = JSON.parse(fs.readFileSync(productsPath, "utf-8"));
        }
        if (fs.existsSync(categoriesPath)) {
            categories = JSON.parse(fs.readFileSync(categoriesPath, "utf-8"));
        }
    } catch (error) {
        console.error("Error reading data files:", error);
    }

    const productIndex = Object.values(products).map((prod: any) => {
        const brandSlug = getProductBrandSlug(prod.categorySlug);
        const brandSearch = `
            ${getBrandNameFromSlug(brandSlug, 'tr')} 
            ${getBrandNameFromSlug(brandSlug, 'en')} 
            ${getBrandNameFromSlug(brandSlug, 'ar')}
        `.trim().replace(/\s+/g, ' ');

        return {
            type: 'product',
            id: prod.id,
            title_tr: prod.i18n?.tr?.title || "",
            title_en: prod.i18n?.en?.title || "",
            title_ar: prod.i18n?.ar?.title || "",
            image: getProductImage(prod.id, prod.image),
            categorySlug: prod.categorySlug,
            brand: brandSlug,
            brandSearch: brandSearch, // Addition to make brands searchable by any language name
            inStock: !prod.stockStatus || prod.stockStatus === 'in_stock',
            stockStatus: prod.stockStatus || 'in_stock',
            price: prod.price
        };
    });

    // Identify parent categories
    const parentSlugs = new Set();
    Object.values(categories).forEach((cat: any) => {
        if (cat.parentSlug) parentSlugs.add(cat.parentSlug);
    });

    const categoryIndex = Object.values(categories)
        .filter((cat: any) => !parentSlugs.has(cat.slug)) // Only leaf categories
        .map((cat: any) => ({
            type: 'category',
            id: cat.slug,
            title_tr: cat.i18n?.tr?.name || "",
            title_en: cat.i18n?.en?.name || "",
            title_ar: cat.i18n?.ar?.name || "",
            image: cat.slug, // Will be resolved by getCategoryImage on client
            parentSlug: cat.parentSlug
        }));

    return new Response(JSON.stringify([...productIndex, ...categoryIndex]), {
        headers: {
            "Content-Type": "application/json",
            "Cache-Control": "public, max-age=60, stale-while-revalidate=300"
        }
    });
}

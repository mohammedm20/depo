
import { getProductImage } from "../../utils/productImages";
import fs from "node:fs";
import path from "node:path";
import { getProductBrandSlug, getBrandNameFromSlug } from "../../utils/brandUtils";

export async function GET() {
    const productsPath = path.join(process.cwd(), "src", "data", "products.json");
    const categoriesPath = path.join(process.cwd(), "src", "data", "categories.json");

    let products: Record<string, any> = {};
    let categories: Record<string, any> = {};

    try {
        if (fs.existsSync(productsPath)) {
            const rawProducts = fs.readFileSync(productsPath, "utf-8").replace(/^\uFEFF/, "");
            products = JSON.parse(rawProducts);
        }
        if (fs.existsSync(categoriesPath)) {
            const rawCategories = fs.readFileSync(categoriesPath, "utf-8").replace(/^\uFEFF/, "");
            categories = JSON.parse(rawCategories);
        }
    } catch (error) {
        console.error("Error reading data files:", error);
    }

    const productIndex = Object.values(products).map((prod: any) => {
        const brandSlug = getProductBrandSlug(prod.categorySlug);
        const cat = categories[prod.categorySlug];

        // Gather all translation text across tr, en, ar
        const specsTextArr: string[] = [];
        ['tr', 'en', 'ar'].forEach(l => {
            const keys = prod.translations?.[l]?.keys || [];
            keys.forEach((spec: { key: string; value: string }) => {
                if (spec.key) specsTextArr.push(spec.key);
                if (spec.value) specsTextArr.push(spec.value);
            });
        });
        const specsSearch = specsTextArr.join(' ');

        // Find primary titles or description snippets
        const descTr = prod.translations?.tr?.keys?.find((k: any) => /açıklama|tanım|title/i.test(k.key))?.value || "";
        const descEn = prod.translations?.en?.keys?.find((k: any) => /description|title/i.test(k.key))?.value || "";
        const descAr = prod.translations?.ar?.keys?.find((k: any) => /شرح|وصف|عنوان/i.test(k.key))?.value || "";

        const title_tr = prod.i18n?.tr?.title || descTr || cat?.i18n?.tr?.name || "";
        const title_en = prod.i18n?.en?.title || descEn || cat?.i18n?.en?.name || "";
        const title_ar = prod.i18n?.ar?.title || descAr || cat?.i18n?.ar?.name || "";

        const brandSearch = `
            ${brandSlug}
            ${getBrandNameFromSlug(brandSlug, 'tr')} 
            ${getBrandNameFromSlug(brandSlug, 'en')} 
            ${getBrandNameFromSlug(brandSlug, 'ar')}
            ${cat?.i18n?.tr?.name || ""}
            ${cat?.i18n?.en?.name || ""}
            ${cat?.i18n?.ar?.name || ""}
            ${specsSearch}
        `.trim().replace(/\s+/g, ' ');

        return {
            type: 'product',
            id: prod.id,
            title_tr,
            title_en,
            title_ar,
            image: getProductImage(prod.id, prod.image),
            categorySlug: prod.categorySlug,
            brand: brandSlug,
            brandSearch,
            inStock: !prod.stockStatus || prod.stockStatus === 'in_stock',
            stockStatus: prod.stockStatus || 'in_stock',
            price: prod.price
        };
    });

    // Identify parent categories
    const parentSlugs = new Set();
    Object.values(categories).forEach((cat: any) => {
        if (cat.parentSlug) parentSlugs.add(cat.parentSlug);
    });

    const categoryIndex = Object.values(categories)
        .filter((cat: any) => !parentSlugs.has(cat.slug)) // Only leaf categories
        .map((cat: any) => ({
            type: 'category',
            id: cat.slug,
            title_tr: cat.i18n?.tr?.name || cat.slug,
            title_en: cat.i18n?.en?.name || cat.slug,
            title_ar: cat.i18n?.ar?.name || cat.slug,
            image: cat.slug,
            parentSlug: cat.parentSlug
        }));

    return new Response(JSON.stringify([...productIndex, ...categoryIndex]), {
        headers: {
            "Content-Type": "application/json",
            "Cache-Control": "public, max-age=60, stale-while-revalidate=300"
        }
    });
}

